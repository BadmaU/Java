package zadanie1;

public class robot {
    public static class robotabilities {
        private int jump=20;
        private int run=100;
    }
    public void jump() {
        System.out.println("robot jumped");
    }

    public void run() {
        System.out.println("robot ran");

    }
}
