package zadanie1;

public class human {
    public static class humanabilities {
        private int jump=5;
        private int run=30;
    }

    public void jump() {
        System.out.println("human jumped");
    }

    public void run() {
        System.out.println(" human ran");

    }

}
