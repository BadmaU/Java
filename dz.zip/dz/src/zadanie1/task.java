package zadanie1;

public class task {
}
