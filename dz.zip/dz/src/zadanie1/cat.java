package zadanie1;

public class cat {
    public static class catabilities {
        private int jump=10;
        private int run=40;
    }
    public void jump() {
        System.out.println("cat jumped");
    }

    public void run() {
        System.out.println("cat ran");

    }


}
