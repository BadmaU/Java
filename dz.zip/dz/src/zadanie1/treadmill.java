package zadanie1;

public class treadmill {
    private int distance;
    private String difficult;

    public treadmill(int distance) {
        this.distance = distance;
        System.out.println();
    }


    public int getDistance() {
        return distance;
    }

    public String getDifficult() {
        return difficult;
    }
}
