package zadanie1;

public class wall {
    private int height;

    public wall (int height) {
        this.height = height;
    }
}